function renderProducts(products) {
    const $productsContainer = $('.products-container');
    const productsHtml = products.map(product => `
        <div class="col-md-4">
            <div class="card border-0 bg-pink-op overflow-hidden">
                <img src="${product.image}" class="card-img-top product-img" alt="${product.name}" />
                <div class="card-body text-center">
                    <h5 class="card-title text-dark">${product.name}</h5>
                    <p class="card-text text-secondary">¥${product.price}</p>
                    <button class="btn btn-primary add-to-cart" data-id="${product.id}">加入购物车</button>
                </div>
            </div>
        </div>
    `).join('');
    $productsContainer.html(productsHtml);
}

// 添加到购物车
function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    const cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    const existingItem = cartItems.find(item => item.id === productId);
    0
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cartItems.push({
            id: product.id,
            name: product.name,
            price: product.price,
            image: product.image,
            quantity: 1
        });
    }

    localStorage.setItem('cartItems', JSON.stringify(cartItems));
    updateCartIcon();
}

// 更新购物车图标
function updateCartIcon() {
    const cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    const totalItems = cartItems.reduce((sum, item) => sum + item.quantity, 0);

    // 更新购物车图标上的数字
    const $cartIcon = $('.bi-cart3');
    const $badge = $cartIcon.next('.cart-badge');

    if (totalItems > 0) {
        if ($badge.length === 0) {
            $cartIcon.after(`<span class="cart-badge badge rounded-pill bg-danger">${totalItems}</span>`);
        } else {
            $badge.text(totalItems);
        }
    } else {
        $badge.remove();
    }
}
function filterProducts(category) {
    const $categoryLinks = $('.mb-5.d-flex.align-items-center.gap-4 a');
    $categoryLinks.removeClass('text-active');
    $categoryLinks.filter(`:contains('${category}')`).addClass('text-active');

    if (category === 'all') {
        renderProducts(products);
    } else {
        const filteredProducts = products.filter(product => product.category === category);
        renderProducts(filteredProducts);
    }
}

function renderBlogs(blogs) {
    const $blogContainer = $('.blog-container');

    const blogsHtml = blogs.map(blog => {
        if (blog.isFeature) {
            return `
                <div class="col-12 mb-4">
                    <div class="card border-0 blog-card">
                        <div class="row g-4">
                            <div class="col-md-4 position-relative">
                                <img src="${blog.image}" class="img-fluid h-100 w-100 object-fit-cover"
                                    alt="${blog.title}" />
                                <div class="date-badge d-flex flex-column align-items-center justify-content-center">
                                    <div class="fw-bold">${blog.dateBadge.month}</div>
                                    <div>${blog.dateBadge.day}</div>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="card-body h-100 d-flex flex-column">
                                    <div class="mb-4">
                                        <h5 class="card-title mb-2">${blog.title}</h5>
                                        <small class="text-muted">发布日期：${blog.date}</small>
                                    </div>
                                    <div class="flex-grow-1 d-flex flex-column justify-content-center">
                                        ${blog.content.map(item => {
                if (typeof item === 'string') {
                    return `<p class="card-text text-secondary">${item}</p>`;
                } else {
                    return `
                                                    <p class="card-text text-secondary">
                                                        Q：${item.question}<br>
                                                        A：${item.answer}
                                                    </p>
                                                `;
                }
            }).join('')}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        } else {
            // 处理普通博客卡片的渲染
            return `
                <div class="col-md-4">
                    <div class="card border-0 blog-card">
                        <div class="position-relative">
                            <img src="${blog.image}" class="card-img-top" alt="${blog.title}" />
                            <div class="date-badge d-flex flex-column align-items-center justify-content-center">
                                <div class="fw-bold">${blog.dateBadge.month}</div>
                                <div>${blog.dateBadge.day}</div>
                            </div>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">${blog.title}</h5>
                            <p class="card-text text-secondary">${blog.content[0]}</p>
                        </div>
                    </div>
                </div>
            `;
        }
    }).join('');

    $blogContainer.html(blogsHtml);
}

// 渲染购物车
function renderCart() {
    const $cartContainer = $('.cart-container');
    const cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];

    if (cartItems.length === 0) {
        $cartContainer.html(`
            <div class="text-center py-5">
                <i class="bi bi-cart3 fs-1 text-secondary"></i>
                <p class="mt-3 text-secondary">购物车是空的</p>
                <a href="product.html" class="btn btn-primary mt-3">去购物</a>
            </div>
        `);
        return;
    }

    const cartHtml = `
        <div class="table-responsive">
            <table class="table align-middle">
                <thead>
                    <tr>
                        <th>商品信息</th>
                        <th>单价</th>
                        <th>数量</th>
                        <th>小计</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    ${cartItems.map(item => `
                        <tr data-id="${item.id}">
                            <td>
                                <div class="d-flex align-items-center gap-3">
                                    <img src="${item.image}" alt="${item.name}" style="width: 80px; height: 80px; object-fit: cover;">
                                    <div>${item.name}</div>
                                </div>
                            </td>
                            <td>¥${item.price}</td>
                            <td>
                                <div class="input-group" style="width: 120px">
                                    <button class="btn btn-outline-secondary decrease-qty" type="button">-</button>
                                    <input type="text" class="form-control text-center item-qty" value="${item.quantity}">
                                    <button class="btn btn-outline-secondary increase-qty" type="button">+</button>
                                </div>
                            </td>
                            <td>¥${item.price * item.quantity}</td>
                            <td>
                                <button class="btn btn-link text-danger remove-item">删除</button>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
        <div class="d-flex justify-content-end align-items-center gap-4 mt-4">
            <div>
                总计：<span class="fs-4 text-danger">¥${cartItems.reduce((total, item) => total + item.price * item.quantity, 0)}</span>
            </div>
            <button class="btn btn-primary checkout-btn">结算</button>
        </div>
    `;

    $cartContainer.html(cartHtml);
}

// 初始化购物车事件
function initCartEvents() {
    const $cartContainer = $('.cart-container');

    // 增加数量
    $cartContainer.on('click', '.increase-qty', function () {
        const $row = $(this).closest('tr');
        const $input = $row.find('.item-qty');
        $input.val(parseInt($input.val()) + 1);
        updateCartItem($row);
    });

    // 减少数量
    $cartContainer.on('click', '.decrease-qty', function () {
        const $row = $(this).closest('tr');
        const $input = $row.find('.item-qty');
        const newValue = parseInt($input.val()) - 1;
        if (newValue >= 1) {
            $input.val(newValue);
            updateCartItem($row);
        }
    });

    // 手动输入数量
    $cartContainer.on('change', '.item-qty', function () {
        const $row = $(this).closest('tr');
        updateCartItem($row);
    });

    // 删除商品
    $cartContainer.on('click', '.remove-item', function () {
        const $row = $(this).closest('tr');
        const id = $row.data('id');
        removeFromCart(id);
        renderCart();
    });
}

// 更新购物车商品
function updateCartItem($row) {
    const id = $row.data('id');
    const quantity = parseInt($row.find('.item-qty').val());
    const cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    const itemIndex = cartItems.findIndex(item => item.id === id);

    if (itemIndex > -1) {
        cartItems[itemIndex].quantity = quantity;
        localStorage.setItem('cartItems', JSON.stringify(cartItems));
        renderCart();
    }
}

// 从购物车移除商品
function removeFromCart(id) {
    const cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    const newCartItems = cartItems.filter(item => item.id !== id);
    localStorage.setItem('cartItems', JSON.stringify(newCartItems));
}

// 更新用户状态显示
function updateUserStatus() {
    const user = JSON.parse(localStorage.getItem('user'));
    if (user && user.isLoggedIn) {
        $('.user-container').html(`
            <div class="dropdown">
                <div role="button" data-bs-toggle="dropdown">
                    <i class="bi bi-person-fill"></i>
                    <span>${user.username}</span>
                </div>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#" id="logout">退出登录</a></li>
                </ul>
            </div>
            <div>
                <a href="cart.html">
                    <i class="bi bi-cart3"></i>
                </a>
            </div>
        `);
    }
}
// 退出登录
$(document).on('click', '#logout', function (e) {
    e.preventDefault();
    localStorage.removeItem('user');
    location.reload();
});

$(document).ready(() => {
    updateCartIcon();
    updateUserStatus();
    // 获取当前页面名称
    const pageName = window.location.pathname.split('/').pop() || 'index.html';

    // 根据页面名称执行对应函数
    switch (pageName) {
        case 'blog.html':
            renderBlogs(blogs);
            break;

        case 'product.html':
            renderProducts(products);
            // 产品页面的分类筛选事件
            $('.mb-5.d-flex.align-items-center.gap-4 a').on('click', function (e) {
                e.preventDefault();
                const category = $(this).text();
                filterProducts(category);
            });
            // 添加购物车点击事件
            $('.products-container').on('click', '.add-to-cart', function (e) {
                e.preventDefault();
                const productId = $(this).data('id');
                addToCart(productId);

                // 显示添加成功提示
                const $btn = $(this);
                const originalText = $btn.text();
                $btn.prop('disabled', true).text('已添加');
                setTimeout(() => {
                    $btn.prop('disabled', false).text(originalText);
                }, 1000);
            });
            break;

        case 'cart.html':
            renderCart();
            initCartEvents();
            break;

        case 'login.html':
            // 登录处理
            $('#loginForm').on('submit', function (e) {
                e.preventDefault();
                const formData = new FormData(this);
                const data = {
                    username: formData.get('username').trim(),
                    password: formData.get('password')
                };

                // 基本验证
                if (!data.username || !data.password) {
                    alert('请填写完整的登录信息');
                    return;
                }

                const registeredUser = JSON.parse(localStorage.getItem('registeredUser'));

                if (!registeredUser || data.username !== registeredUser.username || data.password !== registeredUser.password) {
                    alert('用户名或密码错误');
                    return;
                }

                localStorage.setItem('user', JSON.stringify({
                    username: data.username,
                    isLoggedIn: true
                }));

                window.location.href = 'index.html';
            });
            break;

        case 'register.html':
            // 注册处理

            $('#registerForm').on('submit', async function (e) {
                e.preventDefault();

                const username = $('[name="username"]').val().trim();
                const password = $('[name="password"]').val();

                try {
                    const response = fetch('http://localhost:3000/register', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ username, password })
                    });

                    const result = await response.json();

                    if (response.ok) {
                        alert('注册成功');
                        window.location.href = 'login.html';
                    } else {
                        alert(result.message || '注册失败');
                    }
                } catch (error) {
                    console.error('注册请求失败:', error);
                    alert('网络错误，请稍后重试');
                }
            });
            break;

        default:
            break;
    }
});