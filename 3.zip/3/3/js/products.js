const products = [
    {
        id: 1,
        name: "戒指Q01",
        price: 2900,
        image: "assets/product1_3.webp",
        category: "戒指"
    },
    {
        id: 10,
        name: "戒指Q02",
        price: 2900,
        image: "assets/product4.webp",
        category: "戒指"
    },
    {
        id: 11,
        name: "耳饰Q03",
        price: 2900,
        image: "assets/product5.webp",
        category: "耳饰"
    },
    {
        id: 12,
        name: "耳饰Q04",
        price: 2900,
        image: "assets/product6.webp",
        category: "耳饰"
    },
    {
        id: 13,
        name: "项链Q06",
        price: 2900,
        image: "assets/product7.webp",
        category: "项链"
    },
    {
        id: 14,
        name: "项链Q07",
        price: 2900,
        image: "assets/product8.webp",
        category: "项链"
    },
    {
        id: 15,
        name: "手链Q09",
        price: 2900,
        image: "assets/product9.webp",
        category: "手链"
    },
    {
        id: 2,
        name: "手链S08",
        price: 2900,
        image: "assets/product1.webp",
        category: "手链"
    },
    {
        id: 3,
        name: "手链S07",
        price: 2900,
        image: "assets/product2.webp",
        category: "手链"
    },
    {
        id: 4,
        name: "项链S05",
        price: 2900,
        image: "assets/product3.webp",
        category: "项链"
    },
    {
        id: 5,
        name: "耳饰S01",
        price: 2900,
        image: "assets/product2_1.webp",
        category: "耳饰"
    },
    {
        id: 6,
        name: "耳饰W01",
        price: 2900,
        image: "assets/product2_2.webp",
        category: "耳饰"
    },
    {
        id: 7,
        name: "耳饰Q01",
        price: 2900,
        image: "assets/product2_3.webp",
        category: "耳饰"
    },
    {
        id: 8,
        name: "戒指S01",
        price: 2900,
        image: "assets/product1_1.webp",
        category: "戒指"
    },
    {
        id: 9,
        name: "戒指W01",
        price: 2900,
        image: "assets/product1_2.webp",
        category: "戒指"
    }
];