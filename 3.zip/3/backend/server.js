// server.js 关键配置
const express = require('express');
const path = require('path');
const app = express();

// 托管public目录下的所有文件
app.use(express.static(path.join(__dirname, 'public')));

// 处理所有前端路由（Vue/React等SPA应用必需）
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// 启动服务器
app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});